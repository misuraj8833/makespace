create procedure getFreeMeetingRooms(IN startTime VARCHAR(5), IN endTime VARCHAR(5))
BEGIN

SELECT 
    meetingroom.room_name
FROM 
    meetingroom 
LEFT JOIN 
     reservation 
     ON (
         reservation.room_id = meetingroom.room_id 
		AND 
         NOT ( 
             (reservation.start_time < startTime and reservation.end_time < endTime) 
             OR
             (reservation.start_time > startTime and reservation.end_time > endTime) 
             )
        ) 
where reservation.room_id IS NULL;


END;

